# Ecommerce-Application-using-Microservice-Architecture-Node-Js-RabbitMq-MongoDB

### Services:
  1. Auth Service
  2. Product Service
  3. Order Service

<img src="https://raw.githubusercontent.com/soumyadip007/Ecommerce-Application-using-Microservice-Architecture-Node-Js-RabbitMq-MongoDB/master/flow1.png" >

<img src="https://raw.githubusercontent.com/soumyadip007/Ecommerce-Application-using-Microservice-Architecture-Node-Js-RabbitMq-MongoDB/master/flow2.png" >